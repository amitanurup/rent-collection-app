const DB_NAME = "rent-collection-db";
const DB_STORE = "kv";
const DB_KEY = "app-state";
const NOTIFY_KEY = "rent-collection-last-notified";
const MAX_DOCUMENT_SIZE = 4 * 1024 * 1024;

const formatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
});

const ui = {
  tenantFilter: "all",
  tenantSearch: "",
  selectedTenantId: null,
  activeTab: "overview",
  installPrompt: null,
  toastTimer: null
};

let dbPromise = null;
let state = createDefaultState();
let elements = {};

document.addEventListener("DOMContentLoaded", () => {
  init().catch((error) => {
    console.error(error);
    showToast("App load me problem aayi. Page refresh karke dekhiye.");
  });
});

async function init() {
  cacheElements();
  bindEvents();
  await loadState();
  ensureSelectedTenant();
  populateProfileForm();
  renderAll();
  switchTab(ui.activeTab, { scroll: false });
  registerInstallPrompt();
  registerServiceWorker();
  maybeSendDueNotifications();
}

function cacheElements() {
  elements = {
    profileForm: document.getElementById("profileForm"),
    profileOwnerName: document.getElementById("profileOwnerName"),
    profilePropertyName: document.getElementById("profilePropertyName"),
    profileCity: document.getElementById("profileCity"),
    profileDueDay: document.getElementById("profileDueDay"),
    profileReminderTime: document.getElementById("profileReminderTime"),
    tenantForm: document.getElementById("tenantForm"),
    tenantId: document.getElementById("tenantId"),
    tenantName: document.getElementById("tenantName"),
    tenantMobile: document.getElementById("tenantMobile"),
    tenantRoomNumber: document.getElementById("tenantRoomNumber"),
    tenantFloor: document.getElementById("tenantFloor"),
    tenantStartDate: document.getElementById("tenantStartDate"),
    tenantDueDay: document.getElementById("tenantDueDay"),
    tenantMonthlyRent: document.getElementById("tenantMonthlyRent"),
    tenantWaterBill: document.getElementById("tenantWaterBill"),
    tenantAdvancePaid: document.getElementById("tenantAdvancePaid"),
    tenantAddress: document.getElementById("tenantAddress"),
    tenantNotes: document.getElementById("tenantNotes"),
    tenantAadhaarFile: document.getElementById("tenantAadhaarFile"),
    aadhaarFileHint: document.getElementById("aadhaarFileHint"),
    existingDocumentHint: document.getElementById("existingDocumentHint"),
    resetTenantFormBtn: document.getElementById("resetTenantFormBtn"),
    scrollToCollectionBtn: document.getElementById("scrollToCollectionBtn"),
    paymentForm: document.getElementById("paymentForm"),
    collectionTenantId: document.getElementById("collectionTenantId"),
    collectionMonth: document.getElementById("collectionMonth"),
    collectionRentAmount: document.getElementById("collectionRentAmount"),
    collectionElectricityBill: document.getElementById("collectionElectricityBill"),
    collectionWaterBill: document.getElementById("collectionWaterBill"),
    collectionOtherCharge: document.getElementById("collectionOtherCharge"),
    collectionAdvanceUsed: document.getElementById("collectionAdvanceUsed"),
    collectionPaidAmount: document.getElementById("collectionPaidAmount"),
    collectionPaymentDate: document.getElementById("collectionPaymentDate"),
    collectionPaymentMode: document.getElementById("collectionPaymentMode"),
    collectionNotes: document.getElementById("collectionNotes"),
    collectionModeLabel: document.getElementById("collectionModeLabel"),
    availableAdvanceHint: document.getElementById("availableAdvanceHint"),
    previewTotalAmount: document.getElementById("previewTotalAmount"),
    previewPaidAmount: document.getElementById("previewPaidAmount"),
    previewBalanceAmount: document.getElementById("previewBalanceAmount"),
    receiptPanelTitle: document.getElementById("receiptPanelTitle"),
    receiptPanelNote: document.getElementById("receiptPanelNote"),
    generateReceiptBtn: document.getElementById("generateReceiptBtn"),
    sendSmsReceiptBtn: document.getElementById("sendSmsReceiptBtn"),
    sendReceiptWhatsappBtn: document.getElementById("sendReceiptWhatsappBtn"),
    deleteSavedPaymentBtn: document.getElementById("deleteSavedPaymentBtn"),
    paymentSubmitBtn: document.getElementById("paymentSubmitBtn"),
    resetPaymentFormBtn: document.getElementById("resetPaymentFormBtn"),
    summaryGrid: document.getElementById("summaryGrid"),
    sidebarPropertyName: document.getElementById("sidebarPropertyName"),
    sidebarTenantCount: document.getElementById("sidebarTenantCount"),
    sidebarDueCount: document.getElementById("sidebarDueCount"),
    sidebarReceivedValue: document.getElementById("sidebarReceivedValue"),
    sidebarReminderTime: document.getElementById("sidebarReminderTime"),
    overviewOwnerValue: document.getElementById("overviewOwnerValue"),
    overviewPropertyValue: document.getElementById("overviewPropertyValue"),
    overviewCityValue: document.getElementById("overviewCityValue"),
    overviewReminderValue: document.getElementById("overviewReminderValue"),
    dueList: document.getElementById("dueList"),
    tenantDirectory: document.getElementById("tenantDirectory"),
    tenantDetail: document.getElementById("tenantDetail"),
    tenantSearchInput: document.getElementById("tenantSearchInput"),
    tenantFilters: document.getElementById("tenantFilters"),
    installAppBtn: document.getElementById("installAppBtn"),
    enableNotificationsBtn: document.getElementById("enableNotificationsBtn"),
    exportDataBtn: document.getElementById("exportDataBtn"),
    copyDueSummaryBtn: document.getElementById("copyDueSummaryBtn"),
    createOwnerReminderBtn: document.getElementById("createOwnerReminderBtn"),
    importDataBtn: document.getElementById("importDataBtn"),
    importFileInput: document.getElementById("importFileInput"),
    loadDemoBtn: document.getElementById("loadDemoBtn"),
    clearAllBtn: document.getElementById("clearAllBtn"),
    appToast: document.getElementById("appToast")
  };
}

function bindEvents() {
  document.addEventListener("click", handleAppChromeClick);
  elements.profileForm.addEventListener("submit", handleProfileSave);
  elements.tenantForm.addEventListener("submit", handleTenantSave);
  elements.paymentForm.addEventListener("submit", handlePaymentSave);
  elements.resetTenantFormBtn.addEventListener("click", resetTenantForm);
  elements.scrollToCollectionBtn.addEventListener("click", () => scrollToSection("collectionEntry"));
  elements.resetPaymentFormBtn.addEventListener("click", () => hydratePaymentForm());
  elements.collectionTenantId.addEventListener("change", () => {
    ui.selectedTenantId = elements.collectionTenantId.value || ui.selectedTenantId;
    ensureSelectedTenant();
    renderAll();
    hydratePaymentForm();
  });
  elements.collectionMonth.addEventListener("change", hydratePaymentForm);
  [
    elements.collectionRentAmount,
    elements.collectionElectricityBill,
    elements.collectionWaterBill,
    elements.collectionOtherCharge,
    elements.collectionAdvanceUsed,
    elements.collectionPaidAmount
  ].forEach((field) => field.addEventListener("input", updatePaymentPreview));
  elements.collectionPaymentMode.addEventListener("change", updatePaymentPreview);
  elements.tenantAadhaarFile.addEventListener("change", updateAadhaarHint);
  elements.tenantSearchInput.addEventListener("input", (event) => {
    ui.tenantSearch = cleanString(event.target.value).toLowerCase();
    renderTenantDirectory();
  });
  elements.tenantFilters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-filter]");
    if (!button) {
      return;
    }

    ui.tenantFilter = button.dataset.filter;
    renderTenantDirectory();
    renderFilterChips();
  });
  elements.tenantDirectory.addEventListener("click", handleTenantDirectoryClick);
  elements.dueList.addEventListener("click", handleDueListClick);
  elements.tenantDetail.addEventListener("click", handleTenantDetailClick);
  elements.enableNotificationsBtn.addEventListener("click", requestNotificationPermission);
  elements.installAppBtn.addEventListener("click", installApplication);
  elements.exportDataBtn.addEventListener("click", exportState);
  elements.copyDueSummaryBtn.addEventListener("click", copyDueSummary);
  elements.createOwnerReminderBtn.addEventListener("click", createOwnerReminder);
  elements.generateReceiptBtn.addEventListener("click", generateCurrentReceipt);
  elements.sendSmsReceiptBtn.addEventListener("click", sendCurrentSmsReceipt);
  elements.sendReceiptWhatsappBtn.addEventListener("click", sendCurrentWhatsappReceipt);
  elements.deleteSavedPaymentBtn.addEventListener("click", deleteCurrentSavedPayment);
  elements.importDataBtn.addEventListener("click", () => elements.importFileInput.click());
  elements.importFileInput.addEventListener("change", importStateFile);
  elements.loadDemoBtn.addEventListener("click", loadDemoData);
  elements.clearAllBtn.addEventListener("click", clearAllData);
}

function handleAppChromeClick(event) {
  const tabTrigger = event.target.closest("[data-tab]");
  if (!tabTrigger) {
    return;
  }

  switchTab(tabTrigger.dataset.tab);
}

function createDefaultState() {
  return {
    profile: {
      ownerName: "",
      propertyName: "",
      city: "",
      defaultDueDay: 5,
      reminderTime: "09:00"
    },
    tenants: []
  };
}

function createDemoState() {
  const demo = createDefaultState();
  demo.profile = {
    ownerName: "Amit Kumar",
    propertyName: "Shiv Residency",
    city: "Kendrapara",
    defaultDueDay: 5,
    reminderTime: "08:30"
  };
  demo.tenants = [
    normalizeTenant({
      id: "tenant-demo-1",
      fullName: "Rakesh Das",
      mobile: "9876543210",
      roomNumber: "101",
      floor: "Ground Floor",
      startDate: "2026-01-12",
      dueDay: 5,
      monthlyRent: 4500,
      defaultWaterBill: 250,
      advancePaid: 6000,
      address: "Near bus stand, single room",
      notes: "Meter reading 2380",
      payments: [
        {
          id: "pay-demo-1",
          monthKey: previousMonthKey(),
          rentAmount: 4500,
          electricityBill: 420,
          waterBill: 250,
          otherCharge: 0,
          advanceUsed: 0,
          paidAmount: 5170,
          paymentDate: previousMonthPaymentDate(),
          paymentMode: "upi",
          notes: "Paid full"
        },
        {
          id: "pay-demo-2",
          monthKey: currentMonthKey(),
          rentAmount: 4500,
          electricityBill: 510,
          waterBill: 250,
          otherCharge: 0,
          advanceUsed: 0,
          paidAmount: 3000,
          paymentDate: getTodayIso(),
          paymentMode: "cash",
          notes: "Partial payment"
        }
      ]
    }),
    normalizeTenant({
      id: "tenant-demo-2",
      fullName: "Mina Sahoo",
      mobile: "9123456780",
      roomNumber: "202",
      floor: "First Floor",
      startDate: "2026-03-03",
      dueDay: 7,
      monthlyRent: 5200,
      defaultWaterBill: 300,
      advancePaid: 7000,
      address: "Double room, family stay",
      notes: "Aadhaar pending",
      payments: [
        {
          id: "pay-demo-3",
          monthKey: previousMonthKey(),
          rentAmount: 5200,
          electricityBill: 650,
          waterBill: 300,
          otherCharge: 0,
          advanceUsed: 500,
          paidAmount: 5650,
          paymentDate: previousMonthPaymentDate(),
          paymentMode: "bank",
          notes: "Advance adjusted"
        }
      ]
    })
  ];

  return demo;
}

async function loadState() {
  const saved = await readFromDb(DB_KEY);
  const source = saved && saved.state ? saved.state : saved;
  state = normalizeState(source || createDefaultState());
}

async function persistState() {
  await writeToDb(DB_KEY, {
    savedAt: new Date().toISOString(),
    state
  });
}

function normalizeState(source) {
  const normalized = createDefaultState();
  const profile = source && source.profile ? source.profile : {};
  normalized.profile = {
    ownerName: cleanString(profile.ownerName),
    propertyName: cleanString(profile.propertyName),
    city: cleanString(profile.city),
    defaultDueDay: clampNumber(profile.defaultDueDay, 1, 28, 5),
    reminderTime: isValidTime(profile.reminderTime) ? profile.reminderTime : "09:00"
  };
  normalized.tenants = Array.isArray(source && source.tenants) ? source.tenants.map(normalizeTenant) : [];
  normalized.tenants.sort(sortTenants);
  return normalized;
}

function normalizeTenant(source) {
  const tenant = {
    id: cleanString(source.id) || makeId("tenant"),
    fullName: cleanString(source.fullName),
    mobile: cleanDigits(source.mobile),
    roomNumber: cleanString(source.roomNumber),
    floor: cleanString(source.floor),
    startDate: isValidDate(source.startDate) ? source.startDate : getTodayIso(),
    dueDay: clampNumber(source.dueDay, 1, 28, state.profile ? state.profile.defaultDueDay : 5),
    monthlyRent: toMoney(source.monthlyRent),
    defaultWaterBill: toMoney(source.defaultWaterBill),
    advancePaid: toMoney(source.advancePaid),
    address: cleanString(source.address),
    notes: cleanString(source.notes),
    aadhaarDocument: normalizeDocument(source.aadhaarDocument),
    payments: []
  };

  const seenMonths = new Map();
  const payments = Array.isArray(source.payments) ? source.payments.map(normalizePayment) : [];

  payments.forEach((payment) => {
    seenMonths.set(payment.monthKey, payment);
  });

  tenant.payments = Array.from(seenMonths.values()).sort((left, right) => right.monthKey.localeCompare(left.monthKey));
  return tenant;
}

function normalizeDocument(source) {
  if (!source || !source.dataUrl) {
    return null;
  }

  return {
    name: cleanString(source.name) || "aadhaar-copy",
    type: cleanString(source.type) || "application/octet-stream",
    size: Number(source.size) || 0,
    dataUrl: String(source.dataUrl),
    updatedAt: isValidDateTime(source.updatedAt) ? source.updatedAt : new Date().toISOString()
  };
}

function normalizePayment(source) {
  return {
    id: cleanString(source.id) || makeId("payment"),
    monthKey: isValidMonthKey(source.monthKey) ? source.monthKey : currentMonthKey(),
    rentAmount: toMoney(source.rentAmount),
    electricityBill: toMoney(source.electricityBill),
    waterBill: toMoney(source.waterBill),
    otherCharge: toMoney(source.otherCharge),
    advanceUsed: toMoney(source.advanceUsed),
    paidAmount: toMoney(source.paidAmount),
    paymentDate: isValidDate(source.paymentDate) ? source.paymentDate : "",
    paymentMode: cleanString(source.paymentMode) || "cash",
    notes: cleanString(source.notes)
  };
}

function populateProfileForm() {
  elements.profileOwnerName.value = state.profile.ownerName;
  elements.profilePropertyName.value = state.profile.propertyName;
  elements.profileCity.value = state.profile.city;
  elements.profileDueDay.value = state.profile.defaultDueDay;
  elements.profileReminderTime.value = state.profile.reminderTime;
}

function renderAll() {
  ensureSelectedTenant();
  renderSummary();
  renderProfileSnapshot();
  renderPaymentTenantOptions();
  renderDueList();
  renderTenantDirectory();
  renderTenantDetail();
  renderFilterChips();
  renderTenantDocumentHint();
  hydratePaymentForm(true);
  renderReceiptPanel();
}

function renderSummary() {
  const metrics = getSummaryMetrics();
  elements.summaryGrid.innerHTML = [
    createMetricCard("Total Tenants", metrics.totalTenants, "Active room records", "accent"),
    createMetricCard("This Month Received", formatMoney(metrics.collectedThisMonth), `${metrics.paidTenantCount} tenant updated`, "warm"),
    createMetricCard("Current Pending", formatMoney(metrics.currentPending), `${metrics.dueTenantCount} tenant pending`, "accent"),
    createMetricCard("Advance Balance", formatMoney(metrics.advanceBalance), `${metrics.documentMissingCount} document pending`, "warm")
  ].join("");
  elements.sidebarTenantCount.textContent = String(metrics.totalTenants);
  elements.sidebarDueCount.textContent = String(metrics.dueTenantCount);
  elements.sidebarReceivedValue.textContent = formatMoney(metrics.collectedThisMonth);
}

function renderProfileSnapshot() {
  const propertyName = state.profile.propertyName || "Standalone collection software";
  const ownerName = state.profile.ownerName || "Owner not set";
  const city = state.profile.city || "Area not set";
  const reminderTime = state.profile.reminderTime || "09:00";

  elements.sidebarPropertyName.textContent = propertyName;
  elements.sidebarReminderTime.textContent = reminderTime;
  elements.overviewOwnerValue.textContent = ownerName;
  elements.overviewPropertyValue.textContent = propertyName;
  elements.overviewCityValue.textContent = city;
  elements.overviewReminderValue.textContent = reminderTime;
}

function switchTab(tabName, options = {}) {
  const validTabs = ["overview", "tenants", "collections", "reminders", "settings"];
  if (!validTabs.includes(tabName)) {
    return;
  }

  ui.activeTab = tabName;

  document.querySelectorAll(".nav-tab, .dock-tab").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.tab === tabName);
  });

  document.querySelectorAll("[data-panel]").forEach((panel) => {
    panel.classList.toggle("is-active", panel.dataset.panel === tabName);
  });

  if (options.scroll === false) {
    return;
  }

  window.scrollTo({
    top: 0,
    behavior: isLikelyMobileDevice() ? "smooth" : "auto"
  });
}

function createMetricCard(label, value, note, tone) {
  return `
    <article class="metric-card" data-tone="${tone}">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(String(value))}</strong>
      <span>${escapeHtml(note)}</span>
    </article>
  `;
}

function getSummaryMetrics() {
  let collectedThisMonth = 0;
  let currentPending = 0;
  let advanceBalance = 0;
  let paidTenantCount = 0;
  let dueTenantCount = 0;
  let documentMissingCount = 0;
  const monthKey = currentMonthKey();

  state.tenants.forEach((tenant) => {
    const snapshot = getMonthSnapshot(tenant, monthKey);
    const advance = getAdvanceBalance(tenant);
    advanceBalance += advance;
    currentPending += snapshot.outstanding;
    collectedThisMonth += snapshot.paidAmount;

    if (snapshot.outstanding > 0) {
      dueTenantCount += 1;
    } else if (snapshot.total > 0) {
      paidTenantCount += 1;
    }

    if (!tenant.aadhaarDocument) {
      documentMissingCount += 1;
    }
  });

  return {
    totalTenants: state.tenants.length,
    collectedThisMonth,
    currentPending,
    advanceBalance,
    paidTenantCount,
    dueTenantCount,
    documentMissingCount
  };
}

function renderPaymentTenantOptions() {
  const currentValue = elements.collectionTenantId.value;
  const options = [`<option value="">Select tenant</option>`]
    .concat(
      state.tenants.map(
        (tenant) =>
          `<option value="${escapeHtml(tenant.id)}">${escapeHtml(tenant.fullName)} - Room ${escapeHtml(
            tenant.roomNumber || "-"
          )}</option>`
      )
    )
    .join("");

  elements.collectionTenantId.innerHTML = options;
  const nextValue = currentValue || ui.selectedTenantId || "";

  if (state.tenants.some((tenant) => tenant.id === nextValue)) {
    elements.collectionTenantId.value = nextValue;
  } else if (state.tenants[0]) {
    elements.collectionTenantId.value = state.tenants[0].id;
  } else {
    elements.collectionTenantId.value = "";
  }
}

function hydratePaymentForm(keepManualMonth = true) {
  if (!keepManualMonth || !elements.collectionMonth.value) {
    elements.collectionMonth.value = currentMonthKey();
  }

  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  const monthKey = isValidMonthKey(elements.collectionMonth.value) ? elements.collectionMonth.value : currentMonthKey();

  if (!tenant) {
    elements.collectionModeLabel.textContent = "Tenant add kijiye, phir collection save hoga.";
    elements.availableAdvanceHint.textContent = "Available advance: ₹0";
    elements.paymentSubmitBtn.disabled = true;
    resetPaymentFieldsOnly();
    updatePaymentPreview();
    renderReceiptPanel();
    return;
  }

  elements.paymentSubmitBtn.disabled = false;
  const record = getPaymentByMonth(tenant, monthKey);
  const availableAdvance = getAvailableAdvanceForMonth(tenant, monthKey);

  if (record) {
    elements.collectionModeLabel.textContent = `${formatMonthLabel(monthKey)} record edit ho raha hai.`;
  } else {
    elements.collectionModeLabel.textContent = `${formatMonthLabel(monthKey)} ka naya collection entry.`;
  }

  elements.availableAdvanceHint.textContent = `Available advance: ${formatMoney(availableAdvance)}`;
  elements.collectionRentAmount.value = record ? record.rentAmount : tenant.monthlyRent || "";
  elements.collectionElectricityBill.value = record ? record.electricityBill : "";
  elements.collectionWaterBill.value = record ? record.waterBill : tenant.defaultWaterBill || "";
  elements.collectionOtherCharge.value = record ? record.otherCharge : "";
  elements.collectionAdvanceUsed.value = record ? record.advanceUsed : "";
  elements.collectionPaidAmount.value = record ? record.paidAmount : "";
  elements.collectionPaymentDate.value = record ? record.paymentDate : getTodayIso();
  elements.collectionPaymentMode.value = record ? record.paymentMode : "cash";
  elements.collectionNotes.value = record ? record.notes : "";
  updatePaymentPreview();
  renderReceiptPanel();
}

function resetPaymentFieldsOnly() {
  [
    elements.collectionRentAmount,
    elements.collectionElectricityBill,
    elements.collectionWaterBill,
    elements.collectionOtherCharge,
    elements.collectionAdvanceUsed,
    elements.collectionPaidAmount,
    elements.collectionPaymentDate,
    elements.collectionNotes
  ].forEach((field) => {
    field.value = "";
  });
  elements.collectionPaymentMode.value = "cash";
}

function updatePaymentPreview() {
  const values = getPaymentFormValues();
  const total = roundMoney(values.rentAmount + values.electricityBill + values.waterBill + values.otherCharge - values.advanceUsed);
  const safeTotal = Math.max(0, total);
  const safePaid = Math.max(0, values.paidAmount);
  const balance = Math.max(0, roundMoney(safeTotal - safePaid));
  elements.previewTotalAmount.textContent = formatMoney(safeTotal);
  elements.previewPaidAmount.textContent = formatMoney(safePaid);
  elements.previewBalanceAmount.textContent = formatMoney(balance);
}

function getPaymentFormValues() {
  return {
    rentAmount: toMoney(elements.collectionRentAmount.value),
    electricityBill: toMoney(elements.collectionElectricityBill.value),
    waterBill: toMoney(elements.collectionWaterBill.value),
    otherCharge: toMoney(elements.collectionOtherCharge.value),
    advanceUsed: toMoney(elements.collectionAdvanceUsed.value),
    paidAmount: toMoney(elements.collectionPaidAmount.value)
  };
}

function renderDueList() {
  const dueItems = collectOutstandingItems();

  if (!dueItems.length) {
    elements.dueList.innerHTML = createEmptyState(
      "Koi pending tenant nahi",
      "Current month ke sab records clear hain. Naya month aate hi yahan reminder cards dikh jayenge."
    );
    return;
  }

  elements.dueList.innerHTML = dueItems
    .map((item) => {
      const tone = getStatusTone(item);
      const hint = item.isEstimated ? "Estimated from monthly rent + default water" : "Saved collection record";
      return `
        <article class="due-item">
          <div class="tenant-topline">
            <div>
              <div class="tenant-name">${escapeHtml(item.tenant.fullName)}</div>
              <div class="tenant-subline">
                Room ${escapeHtml(item.tenant.roomNumber || "-")} • ${escapeHtml(formatMonthLabel(item.monthKey))}
              </div>
            </div>
            <span class="status-chip" data-tone="${tone}">${escapeHtml(getStatusLabel(item))}</span>
          </div>

          <div class="metric-strip">
            <div class="detail-metric">
              <span>Total</span>
              <strong>${escapeHtml(formatMoney(item.total))}</strong>
            </div>
            <div class="detail-metric">
              <span>Paid</span>
              <strong>${escapeHtml(formatMoney(item.paidAmount))}</strong>
            </div>
            <div class="detail-metric">
              <span>Balance</span>
              <strong>${escapeHtml(formatMoney(item.outstanding))}</strong>
            </div>
          </div>

          <div class="section-note">${escapeHtml(hint)} • Due day ${escapeHtml(String(getTenantDueDay(item.tenant)))}</div>

          <div class="tenant-actions">
            <button class="mini-button" data-action="select-tenant" data-tenant-id="${escapeHtml(item.tenant.id)}" type="button">Open</button>
            <button class="mini-button" data-action="collect" data-tenant-id="${escapeHtml(item.tenant.id)}" data-month-key="${escapeHtml(
              item.monthKey
            )}" type="button">Collect</button>
            <button class="mini-button" data-action="whatsapp" data-tenant-id="${escapeHtml(item.tenant.id)}" data-month-key="${escapeHtml(
              item.monthKey
            )}" type="button">WhatsApp</button>
            <button class="mini-button" data-action="reminder" data-tenant-id="${escapeHtml(item.tenant.id)}" data-month-key="${escapeHtml(
              item.monthKey
            )}" type="button">Phone Reminder</button>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderTenantDirectory() {
  const tenants = state.tenants.filter(matchesTenantSearchAndFilter);

  if (!tenants.length) {
    elements.tenantDirectory.innerHTML = createEmptyState(
      "Tenant nahi mila",
      "Search ya filter clear karke dekhiye, ya naya tenant add kariye."
    );
    return;
  }

  elements.tenantDirectory.innerHTML = tenants
    .map((tenant) => {
      const current = getMonthSnapshot(tenant, currentMonthKey());
      const totalOutstanding = getTenantOutstandingTotal(tenant);
      const documentTag = tenant.aadhaarDocument
        ? `<span class="tag">Aadhaar saved</span>`
        : `<span class="tag" data-tone="danger">Aadhaar pending</span>`;
      const mobileTag = tenant.mobile
        ? `<span class="tag" data-tone="warm">${escapeHtml(formatMobileForCard(tenant.mobile))}</span>`
        : `<span class="tag" data-tone="danger">Mobile missing</span>`;
      return `
        <article class="tenant-card ${tenant.id === ui.selectedTenantId ? "is-selected" : ""}" tabindex="0" data-card-tenant-id="${escapeHtml(
        tenant.id
      )}">
          <div class="tenant-topline">
            <div>
              <div class="tenant-name">${escapeHtml(tenant.fullName)}</div>
              <div class="tenant-subline">
                Room ${escapeHtml(tenant.roomNumber || "-")} • ${escapeHtml(tenant.floor || "Floor not set")}
              </div>
            </div>
            <span class="status-chip" data-tone="${getStatusTone(current)}">${escapeHtml(getStatusLabel(current))}</span>
          </div>

          <div class="detail-copy">
            <div>Monthly rent: <strong>${escapeHtml(formatMoney(tenant.monthlyRent))}</strong></div>
            <div>Current pending: <strong>${escapeHtml(formatMoney(current.outstanding))}</strong></div>
            <div>Total open balance: <strong>${escapeHtml(formatMoney(totalOutstanding))}</strong></div>
          </div>

          <div class="filter-row">
            ${documentTag}
            ${mobileTag}
            <span class="tag">Advance ${escapeHtml(formatMoney(getAdvanceBalance(tenant)))}</span>
          </div>

          <div class="tenant-actions">
            <button class="mini-button" data-action="edit" data-tenant-id="${escapeHtml(tenant.id)}" type="button">Edit</button>
            <button class="mini-button" data-action="collect" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
              currentMonthKey()
            )}" type="button">Collect</button>
            <button class="mini-button" data-action="whatsapp" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
              currentMonthKey()
            )}" type="button">WhatsApp</button>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderTenantDetail() {
  const tenant = getTenantById(ui.selectedTenantId);

  if (!tenant) {
    elements.tenantDetail.innerHTML = createEmptyState(
      "Tenant select kariye",
      "Right side se kisi tenant card par click kariye, phir uska ledger aur Aadhaar yahan dikh jayega."
    );
    return;
  }

  const current = getMonthSnapshot(tenant, currentMonthKey());
  const openItems = collectOutstandingItems().filter((item) => item.tenant.id === tenant.id);
  const ledgerRows = tenant.payments
    .sort((left, right) => right.monthKey.localeCompare(left.monthKey))
    .map((payment) => {
      const summary = getPaymentSummary(payment);
      return `
        <tr>
          <td>${escapeHtml(formatMonthLabel(payment.monthKey))}</td>
          <td>${escapeHtml(formatMoney(summary.total))}</td>
          <td>${escapeHtml(formatMoney(summary.paidAmount))}</td>
          <td>${escapeHtml(formatMoney(summary.outstanding))}</td>
          <td>${escapeHtml(payment.paymentDate || "-")}</td>
          <td>${escapeHtml(payment.paymentMode || "-")}</td>
          <td>
            <div class="tenant-actions">
              <button class="mini-button" data-action="collect" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
        payment.monthKey
      )}" type="button">Edit</button>
              <button class="mini-button" data-action="receipt" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
        payment.monthKey
      )}" type="button">Receipt</button>
              <button class="mini-button" data-action="sms-receipt" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
        payment.monthKey
      )}" type="button">SMS</button>
              <button class="mini-button" data-action="delete-payment" data-tenant-id="${escapeHtml(
                tenant.id
              )}" data-month-key="${escapeHtml(payment.monthKey)}" data-tone="danger" type="button">Delete</button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");

  elements.tenantDetail.innerHTML = `
    <div class="detail-grid">
      <div class="detail-hero field-wide">
        <div>
          <span class="eyebrow">Room ${escapeHtml(tenant.roomNumber || "-")}</span>
          <h3>${escapeHtml(tenant.fullName)}</h3>
          <div class="tenant-subline">${escapeHtml(tenant.floor || "Floor not set")} • Start ${escapeHtml(
    tenant.startDate
  )}</div>
        </div>

        <div class="detail-actions">
          <button class="mini-button" data-action="edit" data-tenant-id="${escapeHtml(tenant.id)}" type="button">Edit Tenant</button>
          <button class="mini-button" data-action="collect" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
    currentMonthKey()
  )}" data-tone="accent" type="button">Collect</button>
          <button class="mini-button" data-action="whatsapp" data-tenant-id="${escapeHtml(tenant.id)}" data-month-key="${escapeHtml(
    currentMonthKey()
  )}" type="button">WhatsApp</button>
          <button class="mini-button" data-action="delete-tenant" data-tenant-id="${escapeHtml(
            tenant.id
          )}" data-tone="danger" type="button">Delete</button>
        </div>
      </div>

      <div class="detail-metric">
        <span>Current pending</span>
        <strong>${escapeHtml(formatMoney(current.outstanding))}</strong>
      </div>

      <div class="detail-metric">
        <span>Total open balance</span>
        <strong>${escapeHtml(formatMoney(getTenantOutstandingTotal(tenant)))}</strong>
      </div>

      <div class="detail-metric">
        <span>Advance balance</span>
        <strong>${escapeHtml(formatMoney(getAdvanceBalance(tenant)))}</strong>
      </div>

      <div class="doc-card">
        <strong>Contact & Notes</strong>
        <div class="detail-copy">
          <div>Mobile: ${escapeHtml(tenant.mobile || "Not saved")}</div>
          <div>Due day: ${escapeHtml(String(getTenantDueDay(tenant)))}</div>
          <div>Address: ${escapeHtml(tenant.address || "No address note")}</div>
          <div>Notes: ${escapeHtml(tenant.notes || "No notes")}</div>
        </div>
      </div>

      ${renderDocumentCard(tenant)}

      <div class="doc-card field-wide">
        <strong>Pending items</strong>
        ${
          openItems.length
            ? `<div class="filter-row">${openItems
                .map(
                  (item) =>
                    `<span class="tag" data-tone="${getStatusTone(item) === "paid" ? "warm" : "danger"}">${escapeHtml(
                      `${formatMonthLabel(item.monthKey)} • ${formatMoney(item.outstanding)}`
                    )}</span>`
                )
                .join("")}</div>`
            : `<p>No open balance. Current records clear hain.</p>`
        }
      </div>

      <div class="ledger-table-wrap field-wide">
        ${
          ledgerRows
            ? `<table class="ledger-table">
                <thead>
                  <tr>
                    <th>Month</th>
                    <th>Total</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Payment Date</th>
                    <th>Mode</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>${ledgerRows}</tbody>
              </table>`
            : createEmptyState("Ledger empty hai", "Is tenant ke liye abhi tak koi month-wise collection record save nahi hua.")
        }
      </div>
    </div>
  `;
}

function renderDocumentCard(tenant) {
  if (!tenant.aadhaarDocument) {
    return `
      <div class="doc-card">
        <strong>Aadhaar Copy</strong>
        <p>Abhi document upload nahi hua. Tenant edit karke image ya PDF save kijiye.</p>
      </div>
    `;
  }

  const doc = tenant.aadhaarDocument;
  const isImage = doc.type.startsWith("image/");
  const preview = isImage
    ? `<div class="doc-preview"><img src="${doc.dataUrl}" alt="Aadhaar preview for ${escapeHtml(tenant.fullName)}" /></div>`
    : `<div class="doc-preview">
        <div class="empty-state">
          <strong>PDF saved</strong>
          <p>${escapeHtml(doc.name)}</p>
        </div>
      </div>`;

  return `
    <div class="doc-card">
      <strong>Aadhaar Copy</strong>
      ${preview}
      <p>${escapeHtml(doc.name)} • ${escapeHtml(formatFileSize(doc.size))}</p>
      <div class="tenant-actions">
        <a class="mini-button" href="${doc.dataUrl}" target="_blank" rel="noopener">Open File</a>
        <button class="mini-button" data-action="remove-document" data-tenant-id="${escapeHtml(tenant.id)}" data-tone="danger" type="button">Remove</button>
      </div>
    </div>
  `;
}

function renderFilterChips() {
  Array.from(elements.tenantFilters.querySelectorAll("[data-filter]")).forEach((button) => {
    button.classList.toggle("is-active", button.dataset.filter === ui.tenantFilter);
  });
}

function renderTenantDocumentHint() {
  const tenant = getTenantById(elements.tenantId.value);
  const file = elements.tenantAadhaarFile.files[0];

  if (file) {
    elements.existingDocumentHint.textContent = `${file.name} selected • ${formatFileSize(file.size)}`;
    return;
  }

  if (tenant && tenant.aadhaarDocument) {
    elements.existingDocumentHint.textContent = `Current file: ${tenant.aadhaarDocument.name}`;
    return;
  }

  elements.existingDocumentHint.textContent = "";
}

function renderReceiptPanel() {
  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  const monthKey = elements.collectionMonth.value;
  const record = tenant && isValidMonthKey(monthKey) ? getPaymentByMonth(tenant, monthKey) : null;

  if (!tenant || !record) {
    elements.receiptPanelTitle.textContent = "Receipt aur SMS panel";
    elements.receiptPanelNote.textContent =
      "Saved month record par yahan se receipt print, SMS receipt, aur delete action milega.";
    [
      elements.generateReceiptBtn,
      elements.sendSmsReceiptBtn,
      elements.sendReceiptWhatsappBtn,
      elements.deleteSavedPaymentBtn
    ].forEach((button) => {
      button.disabled = true;
    });
    return;
  }

  const summary = getPaymentSummary(record);
  elements.receiptPanelTitle.textContent = `${tenant.fullName} • ${formatMonthLabel(monthKey)}`;
  elements.receiptPanelNote.textContent = `Paid ${formatMoney(summary.paidAmount)} • Balance ${formatMoney(
    summary.outstanding
  )} • Receipt aur mobile share ready.`;
  elements.generateReceiptBtn.disabled = summary.paidAmount <= 0;
  elements.sendSmsReceiptBtn.disabled = summary.paidAmount <= 0 || !tenant.mobile;
  elements.sendReceiptWhatsappBtn.disabled = summary.paidAmount <= 0 || !tenant.mobile;
  elements.deleteSavedPaymentBtn.disabled = false;
}

function handleTenantDirectoryClick(event) {
  const actionButton = event.target.closest("[data-action]");
  if (actionButton) {
    runAction(actionButton.dataset.action, actionButton.dataset.tenantId, actionButton.dataset.monthKey);
    return;
  }

  const card = event.target.closest("[data-card-tenant-id]");
  if (!card) {
    return;
  }

  ui.selectedTenantId = card.dataset.cardTenantId;
  renderTenantDirectory();
  renderTenantDetail();
}

function handleDueListClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button) {
    return;
  }

  runAction(button.dataset.action, button.dataset.tenantId, button.dataset.monthKey);
}

function handleTenantDetailClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button) {
    return;
  }

  runAction(button.dataset.action, button.dataset.tenantId, button.dataset.monthKey);
}

async function runAction(action, tenantId, monthKey) {
  const tenant = getTenantById(tenantId);

  if (!tenant && action !== "select-tenant") {
    return;
  }

  if (action === "select-tenant") {
    ui.selectedTenantId = tenantId;
    switchTab("tenants", { scroll: false });
    renderTenantDirectory();
    renderTenantDetail();
    return;
  }

  if (action === "edit") {
    switchTab("tenants", { scroll: false });
    fillTenantForm(tenant);
    scrollToSection("tenantEntry");
    return;
  }

  if (action === "collect") {
    ui.selectedTenantId = tenant.id;
    switchTab("collections", { scroll: false });
    elements.collectionTenantId.value = tenant.id;
    elements.collectionMonth.value = isValidMonthKey(monthKey) ? monthKey : currentMonthKey();
    renderTenantDirectory();
    renderTenantDetail();
    hydratePaymentForm(true);
    scrollToSection("collectionEntry");
    return;
  }

  if (action === "whatsapp") {
    switchTab("reminders", { scroll: false });
    openWhatsAppReminder(tenant, monthKey);
    return;
  }

  if (action === "receipt") {
    switchTab("collections", { scroll: false });
    openReceiptWindow(tenant, monthKey);
    return;
  }

  if (action === "sms-receipt") {
    switchTab("collections", { scroll: false });
    sendSmsReceipt(tenant, monthKey);
    return;
  }

  if (action === "reminder") {
    switchTab("reminders", { scroll: false });
    createReminderForTenant(tenant, monthKey);
    return;
  }

  if (action === "delete-payment") {
    await deletePaymentRecord(tenant, monthKey);
    return;
  }

  if (action === "remove-document") {
    const confirmDelete = window.confirm("Aadhaar file remove karna hai?");
    if (!confirmDelete) {
      return;
    }

    tenant.aadhaarDocument = null;
    await persistState();
    renderAll();
    showToast("Aadhaar file remove ho gayi.");
    return;
  }

  if (action === "delete-tenant") {
    const confirmDelete = window.confirm(`${tenant.fullName} ka pura record delete karna hai?`);
    if (!confirmDelete) {
      return;
    }

    state.tenants = state.tenants.filter((item) => item.id !== tenant.id);
    if (ui.selectedTenantId === tenant.id) {
      ui.selectedTenantId = state.tenants[0] ? state.tenants[0].id : null;
    }
    await persistState();
    resetTenantForm();
    renderAll();
    showToast("Tenant record delete ho gaya.");
  }
}

async function handleProfileSave(event) {
  event.preventDefault();
  state.profile = {
    ownerName: cleanString(elements.profileOwnerName.value),
    propertyName: cleanString(elements.profilePropertyName.value),
    city: cleanString(elements.profileCity.value),
    defaultDueDay: clampNumber(elements.profileDueDay.value, 1, 28, 5),
    reminderTime: isValidTime(elements.profileReminderTime.value) ? elements.profileReminderTime.value : "09:00"
  };

  state.tenants = state.tenants.map((tenant) =>
    normalizeTenant({
      ...tenant,
      dueDay: tenant.dueDay || state.profile.defaultDueDay
    })
  );

  await persistState();
  renderAll();
  showToast("Setup save ho gaya.");
}

async function handleTenantSave(event) {
  event.preventDefault();
  const fullName = cleanString(elements.tenantName.value);
  const roomNumber = cleanString(elements.tenantRoomNumber.value);

  if (!fullName || !roomNumber) {
    showToast("Tenant name aur room number zaruri hai.");
    return;
  }

  const tenantId = cleanString(elements.tenantId.value) || makeId("tenant");
  const existing = getTenantById(tenantId);
  const file = elements.tenantAadhaarFile.files[0];
  let document = existing ? existing.aadhaarDocument : null;

  if (file) {
    if (file.size > MAX_DOCUMENT_SIZE) {
      showToast("Aadhaar file 4 MB se chhoti rakhiye.");
      return;
    }

    document = await fileToDocument(file);
  }

  const tenant = normalizeTenant({
    id: tenantId,
    fullName,
    mobile: elements.tenantMobile.value,
    roomNumber,
    floor: elements.tenantFloor.value,
    startDate: elements.tenantStartDate.value || getTodayIso(),
    dueDay: clampNumber(elements.tenantDueDay.value, 1, 28, state.profile.defaultDueDay),
    monthlyRent: elements.tenantMonthlyRent.value,
    defaultWaterBill: elements.tenantWaterBill.value,
    advancePaid: elements.tenantAdvancePaid.value,
    address: elements.tenantAddress.value,
    notes: elements.tenantNotes.value,
    aadhaarDocument: document,
    payments: existing ? existing.payments : []
  });

  const otherTenants = state.tenants.filter((item) => item.id !== tenantId);
  otherTenants.push(tenant);
  otherTenants.sort(sortTenants);
  state.tenants = otherTenants;
  ui.selectedTenantId = tenant.id;

  await persistState();
  resetTenantForm();
  renderAll();
  showToast(existing ? "Tenant record update ho gaya." : "Naya tenant save ho gaya.");
}

async function handlePaymentSave(event) {
  event.preventDefault();
  const tenant = getTenantById(elements.collectionTenantId.value);
  const monthKey = elements.collectionMonth.value;

  if (!tenant) {
    showToast("Pehle tenant select kariye.");
    return;
  }

  if (!isValidMonthKey(monthKey)) {
    showToast("Billing month sahi se select kariye.");
    return;
  }

  const payment = normalizePayment({
    id: getPaymentByMonth(tenant, monthKey)?.id || makeId("payment"),
    monthKey,
    rentAmount: elements.collectionRentAmount.value || tenant.monthlyRent,
    electricityBill: elements.collectionElectricityBill.value,
    waterBill: elements.collectionWaterBill.value || tenant.defaultWaterBill,
    otherCharge: elements.collectionOtherCharge.value,
    advanceUsed: elements.collectionAdvanceUsed.value,
    paidAmount: elements.collectionPaidAmount.value,
    paymentDate: elements.collectionPaymentDate.value,
    paymentMode: elements.collectionPaymentMode.value,
    notes: elements.collectionNotes.value
  });

  const availableAdvance = getAvailableAdvanceForMonth(tenant, monthKey);
  const summary = getPaymentSummary(payment);

  if (payment.advanceUsed > availableAdvance) {
    showToast(`Advance balance ${formatMoney(availableAdvance)} se zyada nahi ho sakta.`);
    return;
  }

  if (summary.total < 0) {
    showToast("Advance use total bill se zyada nahi ho sakta.");
    return;
  }

  if (payment.paidAmount > summary.total) {
    showToast("Paid amount total bill se zyada nahi hona chahiye.");
    return;
  }

  tenant.payments = tenant.payments.filter((item) => item.monthKey !== monthKey);
  tenant.payments.push(payment);
  tenant.payments.sort((left, right) => right.monthKey.localeCompare(left.monthKey));
  ui.selectedTenantId = tenant.id;

  await persistState();
  renderAll();
  showToast(`${tenant.fullName} ka ${formatMonthLabel(monthKey)} record save ho gaya. Receipt panel ready hai.`);

  if (payment.paidAmount > 0 && tenant.mobile && isLikelyMobileDevice()) {
    const shouldOpenSms = window.confirm("Collection save ho gaya. Ab SMS receipt open karna hai?");
    if (shouldOpenSms) {
      sendSmsReceipt(tenant, monthKey);
    }
  }
}

function resetTenantForm() {
  elements.tenantForm.reset();
  elements.tenantId.value = "";
  elements.tenantStartDate.value = getTodayIso();
  elements.tenantDueDay.value = state.profile.defaultDueDay;
  elements.tenantAadhaarFile.value = "";
  updateAadhaarHint();
}

function fillTenantForm(tenant) {
  elements.tenantId.value = tenant.id;
  elements.tenantName.value = tenant.fullName;
  elements.tenantMobile.value = tenant.mobile;
  elements.tenantRoomNumber.value = tenant.roomNumber;
  elements.tenantFloor.value = tenant.floor;
  elements.tenantStartDate.value = tenant.startDate;
  elements.tenantDueDay.value = getTenantDueDay(tenant);
  elements.tenantMonthlyRent.value = tenant.monthlyRent;
  elements.tenantWaterBill.value = tenant.defaultWaterBill;
  elements.tenantAdvancePaid.value = tenant.advancePaid;
  elements.tenantAddress.value = tenant.address;
  elements.tenantNotes.value = tenant.notes;
  elements.tenantAadhaarFile.value = "";
  renderTenantDocumentHint();
}

function updateAadhaarHint() {
  const file = elements.tenantAadhaarFile.files[0];
  if (file) {
    elements.aadhaarFileHint.textContent = `${file.name} • ${formatFileSize(file.size)}`;
  } else {
    elements.aadhaarFileHint.textContent = "Image ya PDF, max 4 MB.";
  }
  renderTenantDocumentHint();
}

function ensureSelectedTenant() {
  if (!state.tenants.length) {
    ui.selectedTenantId = null;
    return;
  }

  const exists = state.tenants.some((tenant) => tenant.id === ui.selectedTenantId);
  if (!exists) {
    ui.selectedTenantId = state.tenants[0].id;
  }
}

function matchesTenantSearchAndFilter(tenant) {
  const current = getMonthSnapshot(tenant, currentMonthKey());
  const searchHaystack = [tenant.fullName, tenant.roomNumber, tenant.mobile, tenant.floor].join(" ").toLowerCase();
  const matchesSearch = !ui.tenantSearch || searchHaystack.includes(ui.tenantSearch);

  if (!matchesSearch) {
    return false;
  }

  if (ui.tenantFilter === "due") {
    return getTenantOutstandingTotal(tenant) > 0;
  }

  if (ui.tenantFilter === "paid") {
    return current.total > 0 && current.outstanding === 0;
  }

  if (ui.tenantFilter === "attention") {
    return !tenant.aadhaarDocument || !tenant.mobile || getTenantOutstandingTotal(tenant) > 0;
  }

  return true;
}

function getTenantOutstandingTotal(tenant) {
  const recorded = tenant.payments.reduce((sum, payment) => sum + getPaymentSummary(payment).outstanding, 0);
  const currentMonth = currentMonthKey();
  const hasCurrent = tenant.payments.some((payment) => payment.monthKey === currentMonth);
  const currentEstimated = hasCurrent ? 0 : getMonthSnapshot(tenant, currentMonth).outstanding;
  return roundMoney(recorded + currentEstimated);
}

function getPaymentSummary(payment) {
  const total = roundMoney(
    payment.rentAmount + payment.electricityBill + payment.waterBill + payment.otherCharge - payment.advanceUsed
  );
  const safeTotal = Math.max(0, total);
  const paidAmount = Math.max(0, toMoney(payment.paidAmount));
  const outstanding = Math.max(0, roundMoney(safeTotal - paidAmount));
  return {
    total: safeTotal,
    paidAmount,
    outstanding,
    status: outstanding <= 0 ? "paid" : paidAmount > 0 ? "partial" : "due"
  };
}

function getMonthSnapshot(tenant, monthKey) {
  const record = getPaymentByMonth(tenant, monthKey);
  const dueDate = buildDueDate(monthKey, getTenantDueDay(tenant));

  if (record) {
    const summary = getPaymentSummary(record);
    return {
      ...record,
      ...summary,
      dueDate,
      tenant,
      isEstimated: false
    };
  }

  if (!isTenantActiveForMonth(tenant, monthKey)) {
    return {
      monthKey,
      total: 0,
      paidAmount: 0,
      outstanding: 0,
      dueDate,
      tenant,
      status: "inactive",
      isEstimated: true
    };
  }

  const total = roundMoney(tenant.monthlyRent + tenant.defaultWaterBill);
  const today = startOfDay(new Date());
  const tone = total === 0 ? "inactive" : today > dueDate ? "due" : "upcoming";
  return {
    id: makeId("estimate"),
    monthKey,
    rentAmount: tenant.monthlyRent,
    electricityBill: 0,
    waterBill: tenant.defaultWaterBill,
    otherCharge: 0,
    advanceUsed: 0,
    paidAmount: 0,
    paymentDate: "",
    paymentMode: "pending",
    notes: "",
    total,
    outstanding: total,
    dueDate,
    tenant,
    status: tone,
    isEstimated: true
  };
}

function collectOutstandingItems() {
  const items = [];
  const currentKey = currentMonthKey();

  state.tenants.forEach((tenant) => {
    tenant.payments.forEach((payment) => {
      const summary = getPaymentSummary(payment);
      if (summary.outstanding > 0) {
        items.push({
          ...payment,
          ...summary,
          dueDate: buildDueDate(payment.monthKey, getTenantDueDay(tenant)),
          tenant,
          isEstimated: false,
          status: summary.status
        });
      }
    });

    if (!tenant.payments.some((payment) => payment.monthKey === currentKey)) {
      const current = getMonthSnapshot(tenant, currentKey);
      if (current.outstanding > 0) {
        items.push(current);
      }
    }
  });

  return items.sort((left, right) => {
    if (left.dueDate.getTime() !== right.dueDate.getTime()) {
      return left.dueDate.getTime() - right.dueDate.getTime();
    }

    return right.outstanding - left.outstanding;
  });
}

function getStatusTone(item) {
  if (!item || item.outstanding <= 0 || item.status === "paid") {
    return "paid";
  }

  if (item.status === "partial") {
    return startOfDay(new Date()) > item.dueDate ? "due" : "soon";
  }

  if (item.status === "upcoming") {
    return "neutral";
  }

  return startOfDay(new Date()) > item.dueDate ? "due" : "soon";
}

function getStatusLabel(item) {
  if (!item || item.outstanding <= 0 || item.status === "paid") {
    return "Paid";
  }

  if (item.status === "partial") {
    return "Part Paid";
  }

  if (item.status === "upcoming") {
    return "Upcoming";
  }

  if (startOfDay(new Date()) > item.dueDate) {
    return "Overdue";
  }

  return "Due Soon";
}

function getTenantById(tenantId) {
  return state.tenants.find((tenant) => tenant.id === tenantId) || null;
}

function getPaymentByMonth(tenant, monthKey) {
  return tenant.payments.find((payment) => payment.monthKey === monthKey) || null;
}

function getAdvanceBalance(tenant) {
  const used = tenant.payments.reduce((sum, payment) => sum + toMoney(payment.advanceUsed), 0);
  return Math.max(0, roundMoney(tenant.advancePaid - used));
}

function getAvailableAdvanceForMonth(tenant, monthKey) {
  const usedOtherMonths = tenant.payments
    .filter((payment) => payment.monthKey !== monthKey)
    .reduce((sum, payment) => sum + toMoney(payment.advanceUsed), 0);
  return Math.max(0, roundMoney(tenant.advancePaid - usedOtherMonths));
}

function getTenantDueDay(tenant) {
  return clampNumber(tenant.dueDay, 1, 28, state.profile.defaultDueDay || 5);
}

function buildDueDate(monthKey, dueDay) {
  const [year, month] = monthKey.split("-").map(Number);
  const date = new Date(year, month - 1, Math.min(Math.max(dueDay, 1), 28));
  date.setHours(9, 0, 0, 0);
  return date;
}

function isTenantActiveForMonth(tenant, monthKey) {
  return tenant.startDate.slice(0, 7) <= monthKey;
}

function openWhatsAppReminder(tenant, monthKey = currentMonthKey()) {
  if (!tenant.mobile) {
    showToast("Is tenant ka mobile number save nahi hai.");
    return;
  }

  const snapshot = getMonthSnapshot(tenant, isValidMonthKey(monthKey) ? monthKey : currentMonthKey());
  const phone = normalizeWhatsappNumber(tenant.mobile);
  const owner = state.profile.ownerName || "Owner";
  const property = state.profile.propertyName || "Property";
  const message = [
    `Namaste ${tenant.fullName},`,
    `${formatMonthLabel(snapshot.monthKey)} ke liye ${property} ka collection reminder bheja ja raha hai.`,
    `Rent: ${formatMoney(snapshot.rentAmount || tenant.monthlyRent)}`,
    `Electricity: ${formatMoney(snapshot.electricityBill || 0)}`,
    `Water: ${formatMoney(snapshot.waterBill || tenant.defaultWaterBill)}`,
    `Advance adjust: ${formatMoney(snapshot.advanceUsed || 0)}`,
    `Total payable: ${formatMoney(snapshot.total)}`,
    `Paid: ${formatMoney(snapshot.paidAmount || 0)}`,
    `Balance: ${formatMoney(snapshot.outstanding)}`,
    `Payment ho jaane par please confirm kariye.`,
    `- ${owner}`
  ].join("\n");

  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
}

async function copyDueSummary() {
  const dueItems = collectOutstandingItems();
  if (!dueItems.length) {
    showToast("Copy karne ke liye koi pending summary nahi hai.");
    return;
  }

  const lines = dueItems.map(
    (item) =>
      `${item.tenant.fullName} | Room ${item.tenant.roomNumber || "-"} | ${formatMonthLabel(item.monthKey)} | Balance ${formatMoney(
        item.outstanding
      )}`
  );
  const heading = `${state.profile.propertyName || "Property"} pending summary`;
  const text = [heading, ...lines].join("\n");
  await copyText(text);
  showToast("Due summary copy ho gayi.");
}

function createOwnerReminder() {
  const dueItems = collectOutstandingItems();
  if (!dueItems.length) {
    showToast("Reminder banane ke liye koi pending entry nahi hai.");
    return;
  }

  const description = dueItems
    .slice(0, 10)
    .map(
      (item) =>
        `${item.tenant.fullName} | Room ${item.tenant.roomNumber || "-"} | ${formatMonthLabel(item.monthKey)} | ${formatMoney(
          item.outstanding
        )}`
    )
    .join("\\n");

  downloadReminderFile({
    title: `${state.profile.propertyName || "Property"} due collection follow-up`,
    description,
    date: nextReminderDate()
  });
  showToast("Phone reminder file ready hai.");
}

function createReminderForTenant(tenant, monthKey = currentMonthKey()) {
  const snapshot = getMonthSnapshot(tenant, isValidMonthKey(monthKey) ? monthKey : currentMonthKey());
  const description = [
    `Tenant: ${tenant.fullName}`,
    `Room: ${tenant.roomNumber || "-"}`,
    `Month: ${formatMonthLabel(snapshot.monthKey)}`,
    `Balance: ${formatMoney(snapshot.outstanding)}`,
    `Mobile: ${tenant.mobile || "-"}`,
    `Property: ${state.profile.propertyName || "-"}`
  ].join("\\n");

  downloadReminderFile({
    title: `Collect from ${tenant.fullName}`,
    description,
    date: snapshot.dueDate
  });
  showToast("Tenant reminder file ready hai.");
}

async function exportState() {
  const payload = {
    exportedAt: new Date().toISOString(),
    version: 1,
    state
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  downloadBlob(blob, `rent-collection-drive-backup-${getTodayIso()}.json`);
  showToast("Backup JSON export ho gaya. Is file ko Google Drive me upload kar sakte hain.");
}

async function importStateFile(event) {
  const file = event.target.files[0];
  if (!file) {
    return;
  }

  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    state = normalizeState(parsed.state || parsed);
    ensureSelectedTenant();
    await persistState();
    resetTenantForm();
    populateProfileForm();
    renderAll();
    showToast("Backup import ho gaya.");
  } catch (error) {
    console.error(error);
    showToast("Backup file read nahi hua.");
  } finally {
    elements.importFileInput.value = "";
  }
}

async function loadDemoData() {
  const shouldLoad = window.confirm("Demo data load karna hai? Existing data replace ho jayega.");
  if (!shouldLoad) {
    return;
  }

  state = createDemoState();
  ui.selectedTenantId = state.tenants[0] ? state.tenants[0].id : null;
  await persistState();
  resetTenantForm();
  populateProfileForm();
  renderAll();
  showToast("Demo data load ho gaya.");
}

async function clearAllData() {
  const shouldClear = window.confirm("Pura rent data clear karna hai? Isko undo nahi kar sakte.");
  if (!shouldClear) {
    return;
  }

  state = createDefaultState();
  ui.selectedTenantId = null;
  await persistState();
  resetTenantForm();
  populateProfileForm();
  renderAll();
  showToast("Sab data clear ho gaya.");
}

function generateCurrentReceipt() {
  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  if (!tenant) {
    showToast("Pehle tenant select kariye.");
    return;
  }

  openReceiptWindow(tenant, elements.collectionMonth.value || currentMonthKey());
}

function sendCurrentSmsReceipt() {
  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  if (!tenant) {
    showToast("Pehle tenant select kariye.");
    return;
  }

  sendSmsReceipt(tenant, elements.collectionMonth.value || currentMonthKey());
}

function sendCurrentWhatsappReceipt() {
  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  if (!tenant) {
    showToast("Pehle tenant select kariye.");
    return;
  }

  sendWhatsappReceipt(tenant, elements.collectionMonth.value || currentMonthKey());
}

async function deleteCurrentSavedPayment() {
  const tenant = getTenantById(elements.collectionTenantId.value || ui.selectedTenantId);
  if (!tenant) {
    showToast("Pehle tenant select kariye.");
    return;
  }

  await deletePaymentRecord(tenant, elements.collectionMonth.value || currentMonthKey());
}

async function deletePaymentRecord(tenant, monthKey) {
  const existing = getPaymentByMonth(tenant, monthKey);
  if (!existing) {
    showToast("Is month ke liye koi saved record nahi mila.");
    return;
  }

  const shouldDelete = window.confirm(`${tenant.fullName} ka ${formatMonthLabel(monthKey)} record delete karna hai?`);
  if (!shouldDelete) {
    return;
  }

  tenant.payments = tenant.payments.filter((payment) => payment.monthKey !== monthKey);
  await persistState();
  renderAll();
  showToast(`${formatMonthLabel(monthKey)} record delete ho gaya.`);
}

async function requestNotificationPermission() {
  if (!("Notification" in window)) {
    showToast("Is browser me notification support nahi hai.");
    return;
  }

  const permission = await Notification.requestPermission();
  if (permission === "granted") {
    showToast("Phone alert permission mil gaya.");
    maybeSendDueNotifications(true);
  } else {
    showToast("Notification permission allow nahi hua.");
  }
}

async function maybeSendDueNotifications(force = false) {
  if (!("Notification" in window) || Notification.permission !== "granted") {
    return;
  }

  const dueItems = collectOutstandingItems();
  if (!dueItems.length) {
    return;
  }

  const todayKey = getTodayIso();
  if (!force && localStorage.getItem(NOTIFY_KEY) === todayKey) {
    return;
  }

  const preview = dueItems
    .slice(0, 3)
    .map((item) => `${item.tenant.fullName}: ${formatMoney(item.outstanding)}`)
    .join(", ");

  try {
    if ("serviceWorker" in navigator) {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification("Rent collection reminder", {
        body: preview,
        icon: "assets/icons/rent-collection-icon.svg",
        badge: "assets/icons/rent-collection-icon.svg",
        tag: "rent-collection-reminder"
      });
    } else {
      // Fallback for browsers without service worker registration.
      new Notification("Rent collection reminder", {
        body: preview
      });
    }

    localStorage.setItem(NOTIFY_KEY, todayKey);
  } catch (error) {
    console.error(error);
  }
}

function buildReceiptContext(tenant, monthKey) {
  const record = getPaymentByMonth(tenant, monthKey);
  if (!record) {
    return null;
  }

  const snapshot = getMonthSnapshot(tenant, monthKey);
  return {
    tenant,
    record,
    snapshot,
    propertyName: state.profile.propertyName || "Property",
    ownerName: state.profile.ownerName || "Owner",
    city: state.profile.city || "",
    receiptNumber: `RC-${monthKey.replace("-", "")}-${slugify(tenant.roomNumber || tenant.fullName).toUpperCase() || "ROOM"}`
  };
}

function buildReceiptMessage(context) {
  const { tenant, snapshot, propertyName, ownerName, receiptNumber } = context;
  return [
    `Receipt: ${receiptNumber}`,
    `${propertyName}`,
    `Tenant: ${tenant.fullName}`,
    `Room: ${tenant.roomNumber || "-"}`,
    `Month: ${formatMonthLabel(snapshot.monthKey)}`,
    `Received: ${formatMoney(snapshot.paidAmount)}`,
    `Total bill: ${formatMoney(snapshot.total)}`,
    `Balance: ${formatMoney(snapshot.outstanding)}`,
    `Mode: ${snapshot.paymentMode || "-"}`,
    `Date: ${snapshot.paymentDate || getTodayIso()}`,
    `Thanks - ${ownerName}`
  ].join("\n");
}

function openReceiptWindow(tenant, monthKey) {
  const context = buildReceiptContext(tenant, isValidMonthKey(monthKey) ? monthKey : currentMonthKey());
  if (!context) {
    showToast("Receipt banane ke liye saved month record chahiye.");
    return;
  }

  if (context.snapshot.paidAmount <= 0) {
    showToast("Receipt tabhi banega jab paid amount save ho.");
    return;
  }

  const receiptWindow = window.open("", "_blank", "noopener,noreferrer");
  if (!receiptWindow) {
    showToast("Receipt window block ho gaya. Pop-up allow kijiye.");
    return;
  }

  const receiptHtml = `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>${escapeHtml(context.receiptNumber)}</title>
        <style>
          body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f7f1e8;
            color: #183028;
            padding: 24px;
          }
          .sheet {
            max-width: 760px;
            margin: 0 auto;
            background: #fff;
            border-radius: 24px;
            padding: 28px;
            box-shadow: 0 18px 40px rgba(0, 0, 0, 0.08);
          }
          .topline, .row, .meta {
            display: flex;
            justify-content: space-between;
            gap: 14px;
            flex-wrap: wrap;
          }
          .topline {
            padding-bottom: 18px;
            border-bottom: 1px solid #d8d4cb;
          }
          h1, h2, p {
            margin: 0;
          }
          h1 {
            font-size: 30px;
          }
          .meta {
            margin-top: 8px;
            color: #56635b;
          }
          .card {
            margin-top: 20px;
            padding: 18px;
            border-radius: 18px;
            background: #f8f5ef;
            border: 1px solid #ece5da;
          }
          .row {
            padding: 12px 0;
            border-bottom: 1px dashed #d7d0c4;
          }
          .row:last-child {
            border-bottom: 0;
          }
          .total {
            margin-top: 18px;
            padding: 18px;
            border-radius: 18px;
            background: #1d7a5b;
            color: #fff8ef;
          }
          .actions {
            margin-top: 20px;
          }
          button {
            min-height: 44px;
            padding: 0 18px;
            border-radius: 999px;
            border: 0;
            background: #183028;
            color: #fff8ef;
            cursor: pointer;
          }
          @media print {
            body {
              background: #fff;
              padding: 0;
            }
            .sheet {
              box-shadow: none;
              border-radius: 0;
            }
            .actions {
              display: none;
            }
          }
        </style>
      </head>
      <body>
        <div class="sheet">
          <div class="topline">
            <div>
              <p>${escapeHtml(context.propertyName)}</p>
              <h1>Money Receipt</h1>
              <div class="meta">
                <span>${escapeHtml(context.ownerName)}</span>
                <span>${escapeHtml(context.city || "City not set")}</span>
              </div>
            </div>
            <div>
              <p><strong>${escapeHtml(context.receiptNumber)}</strong></p>
              <p>${escapeHtml(context.snapshot.paymentDate || getTodayIso())}</p>
            </div>
          </div>

          <div class="card">
            <div class="row"><span>Tenant</span><strong>${escapeHtml(context.tenant.fullName)}</strong></div>
            <div class="row"><span>Room</span><strong>${escapeHtml(context.tenant.roomNumber || "-")}</strong></div>
            <div class="row"><span>Month</span><strong>${escapeHtml(formatMonthLabel(context.snapshot.monthKey))}</strong></div>
            <div class="row"><span>Payment Mode</span><strong>${escapeHtml(context.snapshot.paymentMode || "-")}</strong></div>
          </div>

          <div class="card">
            <div class="row"><span>Rent</span><strong>${escapeHtml(formatMoney(context.snapshot.rentAmount || context.tenant.monthlyRent))}</strong></div>
            <div class="row"><span>Electricity</span><strong>${escapeHtml(formatMoney(context.snapshot.electricityBill || 0))}</strong></div>
            <div class="row"><span>Water</span><strong>${escapeHtml(formatMoney(context.snapshot.waterBill || context.tenant.defaultWaterBill))}</strong></div>
            <div class="row"><span>Other Charge</span><strong>${escapeHtml(formatMoney(context.snapshot.otherCharge || 0))}</strong></div>
            <div class="row"><span>Advance Used</span><strong>${escapeHtml(formatMoney(context.snapshot.advanceUsed || 0))}</strong></div>
          </div>

          <div class="total">
            <div class="row"><span>Total Bill</span><strong>${escapeHtml(formatMoney(context.snapshot.total))}</strong></div>
            <div class="row"><span>Received</span><strong>${escapeHtml(formatMoney(context.snapshot.paidAmount))}</strong></div>
            <div class="row"><span>Balance</span><strong>${escapeHtml(formatMoney(context.snapshot.outstanding))}</strong></div>
          </div>

          <div class="actions">
            <button onclick="window.print()">Print / Save PDF</button>
          </div>
        </div>
      </body>
    </html>
  `;

  receiptWindow.document.open();
  receiptWindow.document.write(receiptHtml);
  receiptWindow.document.close();
}

function sendSmsReceipt(tenant, monthKey) {
  const context = buildReceiptContext(tenant, isValidMonthKey(monthKey) ? monthKey : currentMonthKey());
  if (!context) {
    showToast("SMS receipt ke liye saved month record chahiye.");
    return;
  }

  if (!tenant.mobile) {
    showToast("SMS bhejne ke liye mobile number save kariye.");
    return;
  }

  const message = buildReceiptMessage(context);
  const smsLink = `sms:${normalizeSmsNumber(tenant.mobile)}?&body=${encodeURIComponent(message)}`;
  window.location.href = smsLink;
}

function sendWhatsappReceipt(tenant, monthKey) {
  const context = buildReceiptContext(tenant, isValidMonthKey(monthKey) ? monthKey : currentMonthKey());
  if (!context) {
    showToast("WhatsApp receipt ke liye saved month record chahiye.");
    return;
  }

  if (!tenant.mobile) {
    showToast("WhatsApp bhejne ke liye mobile number save kariye.");
    return;
  }

  const message = buildReceiptMessage(context);
  const phone = normalizeWhatsappNumber(tenant.mobile);
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank", "noopener");
}

function registerInstallPrompt() {
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    ui.installPrompt = event;
    elements.installAppBtn.hidden = false;
  });

  window.addEventListener("appinstalled", () => {
    ui.installPrompt = null;
    elements.installAppBtn.hidden = true;
    showToast("App install ho gaya.");
  });
}

async function installApplication() {
  if (!ui.installPrompt) {
    showToast("Install option browser jab dega tab yeh button active hoga.");
    return;
  }

  ui.installPrompt.prompt();
  await ui.installPrompt.userChoice;
  ui.installPrompt = null;
  elements.installAppBtn.hidden = true;
}

function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) {
    return;
  }

  navigator.serviceWorker.register("rent-collection-sw.js").catch((error) => {
    console.error(error);
  });
}

function downloadReminderFile({ title, description, date }) {
  const start = combineDateAndTime(date, state.profile.reminderTime || "09:00");
  const end = new Date(start.getTime() + 30 * 60 * 1000);
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Codex//RentCollection//EN",
    "BEGIN:VEVENT",
    `UID:${makeId("reminder")}@rent-collection`,
    `DTSTAMP:${formatIcsDate(new Date())}`,
    `DTSTART:${formatIcsDate(start)}`,
    `DTEND:${formatIcsDate(end)}`,
    `SUMMARY:${escapeIcs(title)}`,
    `DESCRIPTION:${escapeIcs(description)}`,
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");

  const blob = new Blob([ics], { type: "text/calendar;charset=utf-8" });
  downloadBlob(blob, `${slugify(title)}.ics`);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

function createEmptyState(title, body) {
  return `
    <div class="empty-state">
      <strong>${escapeHtml(title)}</strong>
      <p>${escapeHtml(body)}</p>
    </div>
  `;
}

function showToast(message) {
  elements.appToast.textContent = message;
  elements.appToast.classList.add("is-visible");
  clearTimeout(ui.toastTimer);
  ui.toastTimer = window.setTimeout(() => {
    elements.appToast.classList.remove("is-visible");
  }, 2600);
}

function scrollToSection(id) {
  const target = document.getElementById(id);
  const sectionTabMap = {
    tenantEntry: "tenants",
    collectionEntry: "collections"
  };

  if (sectionTabMap[id]) {
    switchTab(sectionTabMap[id], { scroll: false });
  }

  if (target) {
    requestAnimationFrame(() => {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }
}

function formatMoney(value) {
  return formatter.format(Number(value) || 0);
}

function formatMonthLabel(monthKey) {
  if (!isValidMonthKey(monthKey)) {
    return "-";
  }

  const [year, month] = monthKey.split("-").map(Number);
  return new Date(year, month - 1, 1).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric"
  });
}

function formatMobileForCard(value) {
  if (!value) {
    return "-";
  }

  if (value.length === 10) {
    return `+91 ${value}`;
  }

  return value;
}

function normalizeWhatsappNumber(value) {
  const digits = cleanDigits(value);
  if (digits.length === 10) {
    return `91${digits}`;
  }
  return digits;
}

function normalizeSmsNumber(value) {
  const digits = cleanDigits(value);
  if (digits.length === 10) {
    return `+91${digits}`;
  }
  return digits.startsWith("+") ? digits : `+${digits}`;
}

function isLikelyMobileDevice() {
  return /android|iphone|ipad|ipod/i.test(navigator.userAgent || "");
}

function formatFileSize(bytes) {
  if (!bytes) {
    return "0 KB";
  }

  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }

  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function slugify(value) {
  return cleanString(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function cleanString(value) {
  return String(value || "").trim();
}

function cleanDigits(value) {
  return String(value || "").replace(/\D+/g, "");
}

function toMoney(value) {
  return roundMoney(Number(value) || 0);
}

function roundMoney(value) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

function clampNumber(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, Math.round(number)));
}

function makeId(prefix) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

function sortTenants(left, right) {
  const roomCompare = String(left.roomNumber || "").localeCompare(String(right.roomNumber || ""), undefined, {
    numeric: true,
    sensitivity: "base"
  });
  if (roomCompare !== 0) {
    return roomCompare;
  }
  return String(left.fullName || "").localeCompare(String(right.fullName || ""));
}

function isValidDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(value || ""));
}

function isValidDateTime(value) {
  return !Number.isNaN(Date.parse(value));
}

function isValidMonthKey(value) {
  return /^\d{4}-\d{2}$/.test(String(value || ""));
}

function isValidTime(value) {
  return /^\d{2}:\d{2}$/.test(String(value || ""));
}

function getTodayIso() {
  const now = new Date();
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

function currentMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;
}

function previousMonthKey() {
  const now = new Date();
  const previous = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  return `${previous.getFullYear()}-${pad(previous.getMonth() + 1)}`;
}

function previousMonthPaymentDate() {
  const previous = new Date();
  previous.setMonth(previous.getMonth() - 1);
  previous.setDate(Math.min(previous.getDate(), 25));
  return `${previous.getFullYear()}-${pad(previous.getMonth() + 1)}-${pad(previous.getDate())}`;
}

function nextReminderDate() {
  const today = new Date();
  const next = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  next.setDate(next.getDate() + 1);
  return next;
}

function startOfDay(date) {
  const result = new Date(date);
  result.setHours(0, 0, 0, 0);
  return result;
}

function pad(value) {
  return String(value).padStart(2, "0");
}

function combineDateAndTime(date, time) {
  const [hours, minutes] = (time || "09:00").split(":").map(Number);
  const value = new Date(date);
  value.setHours(hours || 9, minutes || 0, 0, 0);
  return value;
}

function formatIcsDate(date) {
  return [
    date.getUTCFullYear(),
    pad(date.getUTCMonth() + 1),
    pad(date.getUTCDate())
  ].join("") +
    "T" +
    [pad(date.getUTCHours()), pad(date.getUTCMinutes()), pad(date.getUTCSeconds())].join("") +
    "Z";
}

function escapeIcs(value) {
  return String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/\n/g, "\\n")
    .replace(/,/g, "\\,")
    .replace(/;/g, "\\;");
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function copyText(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const input = document.createElement("textarea");
  input.value = text;
  document.body.appendChild(input);
  input.select();
  document.execCommand("copy");
  document.body.removeChild(input);
}

async function fileToDocument(file) {
  const dataUrl = await readFileAsDataUrl(file);
  return {
    name: file.name,
    type: file.type || "application/octet-stream",
    size: file.size,
    dataUrl,
    updatedAt: new Date().toISOString()
  };
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

async function readFromDb(key) {
  try {
    const db = await getDb();
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction(DB_STORE, "readonly");
      const store = transaction.objectStore(DB_STORE);
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function writeToDb(key, value) {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DB_STORE, "readwrite");
    const store = transaction.objectStore(DB_STORE);
    store.put(value, key);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

function getDb() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, 1);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(DB_STORE)) {
          request.result.createObjectStore(DB_STORE);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  return dbPromise;
}
