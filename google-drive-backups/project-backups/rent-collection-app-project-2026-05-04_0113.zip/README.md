# Rent Collection App

Standalone mobile-friendly rent collection web app for:

- Tenant register
- Monthly rent, electricity, water, and other charges
- Advance tracking and adjustment
- Aadhaar copy upload
- Due reminders by WhatsApp and calendar
- SMS receipt and printable money receipt
- Google Drive-ready backup flow for JSON data and project ZIP archives

## Open

1. Run `start-local-site.ps1`
2. Open `http://127.0.0.1:8091`

You can also open `index.html` directly, but PWA/offline features work best on local server.

## Google Drive Backup

- Run `prepare-google-drive-backup.ps1` to create a project ZIP backup.
- Use the app `Backup Data` button to download JSON data backups.
- Full instructions: `GOOGLE-DRIVE-BACKUP.md`
