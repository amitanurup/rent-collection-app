# Google Drive Backup Guide

Yeh app do tarah ke backup use karta hai:

1. `Data backup`
   App ke andar `Backup Data` button se tenant aur ledger ka JSON export hota hai.
2. `Project backup`
   Software files ka ZIP backup `prepare-google-drive-backup.ps1` se banta hai.

## Recommended Google Drive Folder Structure

Google Drive me ek folder banaaiye:

- `Rent Collection App Backups`

Uske andar do subfolders rakhiye:

- `data-backups`
- `project-backups`

## Data Backup Steps

1. App open kijiye.
2. `Backup Data` button dabaiye.
3. Download hui `.json` file ko Google Drive ke `data-backups` folder me upload kijiye.

Suggested file example:

- `rent-collection-drive-backup-2026-05-04.json`

## Project Backup Steps

1. `prepare-google-drive-backup.ps1` run kijiye.
2. ZIP file `google-drive-backups/project-backups/` me ban jayegi.
3. Us ZIP ko Google Drive ke `project-backups` folder me upload kijiye.

Suggested project ZIP example:

- `rent-collection-app-project-2026-05-04_1030.zip`

## Restore

### Data Restore

1. App open kijiye.
2. `Import Backup` button dabaiye.
3. Google Drive se download ki hui JSON file select kijiye.

### Project Restore

1. Google Drive se latest project ZIP download kijiye.
2. ZIP extract kijiye.
3. `start-local-site.ps1` run kijiye.

## Good Practice

- Har major collection update ke baad JSON backup upload kariye.
- Hafte me kam se kam ek baar project ZIP backup bhi banaaiye.
- Aadhaar documents JSON backup ke andar included rehte hain, isliye Drive folder private rakhiye.
